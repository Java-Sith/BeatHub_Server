package Invasion;
import java.awt.Color;
import javax.swing.JFrame;

public class Frame extends JFrame{
	private Juego juego;
	public Frame()
	{
		super ("Space Invaders");
		this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		juego = new Juego();
		juego.setDoubleBuffered(true);
		this.getContentPane().add(juego);
		this.pack();
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		juego.Start();
	}
}