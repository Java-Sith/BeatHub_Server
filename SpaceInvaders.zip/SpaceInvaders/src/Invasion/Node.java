package Invasion;

public class Node {
    public Node next;
    Enemigo e;
    
    public Node(Enemigo e) 
    {
        this.next = null;
        this.e = e;
    }
	public Object getData() {
        return this.e;
    }
    public void setData(Enemigo e) {
        this.e = e;
    }
    public Node getNext() {
        return this.next;
    }
    public void setNext(Node node) {
        this.next = node;
    }
}
