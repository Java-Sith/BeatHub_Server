package Invasion;

public class LinkedList 
{
    private Node head;
    private int size;
    
    public LinkedList() 
    {
        this.head = null;
        this.size = 0;
    }

    public boolean isEmpty() 
    {
        return this.head == null;
    }
    public int size() 
    {
        return this.size;
    }
    public int getSize ()
    {
    	return size;
    }

    public void insertFirst(Enemigo e) {
        Node newNode = new Node(e);
        newNode.next = this.head;
        this.head = newNode;
        this.size++;
    }

    public Node deleteFirst() {
        if (this.head != null) 
        {
            Node temp = this.head;
            this.head = this.head.next;
            this.size--;
            return temp;
        } 
        else 
        {
            return null;
        }
    }

    public void displayList() {
        Node current = this.head;
        while (current != null) 
        {
            System.out.println(current.getData());
            current = current.getNext();
        }
    }
    public Node find(Object searchValue) {
        Node current = this.head;
        while (current != null) 
        {
            if (current.equals(searchValue)) 
            {
                return current;
            }
            else 
            {
                current = current.getNext();
            }
        }
        return null;
    }
    public Enemigo get(int i) 
    {
    	Node current = head;
    	int contador = 0;
    	while (current != null)
    	{
    		if (contador == i)
    		{
    			return current.e;
    		}
    		contador++;
    		current = current.next;
    	}
    	return null;
    }
    public Node delete(Object searchValue) 
    {
        Node current = this.head;
        Node previous = this.head;

        while (current != null) 
        {
            if (current.getData().equals(searchValue)) 
            {
                if (current == this.head) 
                {
                    this.head = this.head.getNext();
                } 
                else 
                {
                    previous.setNext(current.getNext());
                }
                this.size --;
                return current;
            }
            else 
            {
                previous = current;
                current = current.getNext();
            }
        }
        return null;
    }
    public void insertAnyPosition(Enemigo e, int position) {
        Node current = this.head;
        int contador = 2;
        if (position <= this.size) 
        {
            while (current != null) 
            {
                if (position == 1) 
                {
                    insertFirst(e);
                    break;
                }
                if (contador == position) 
                {
                    Node newNode = new Node(e);
                    Node next = current.getNext();
                    current.setNext(newNode);
                    newNode.setNext(next);
                    this.size++;
                    contador++;
                }
                else 
                {
                    current = current.getNext();
                    contador++;
                }
            }
        }
        else 
        {
            System.out.println("La posicion indicada no es correcta.");
        }
    }
    public void sortData() 
    {
        if (this.size > 1) 
        {
            for (int i = 0; i < this.size; i++) 
            {
                Node currentNode = this.head;
                Node next = this.head.getNext();
                for (int j = 0; j < this.size - 1; j++) 
                {
                    if (currentNode.getData().hashCode() > next.getData().hashCode()) 
                    {
                        currentNode.setNext(next);
                        next.setNext(currentNode);
                    }
                    currentNode.setNext(next);
                    next.setNext(next.getNext());
                }
            }
        }
    }
}
