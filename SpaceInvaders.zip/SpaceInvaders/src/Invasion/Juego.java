package Invasion;
import Controls.Teclado;
import Invasion.Misil;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.net.URL;
import javax.sound.sampled.*;
import java.util.Scanner;

public class Juego extends JPanel {
	private Timer GameTimer;
	private Teclado teclado;
	private final int gameW = 800;
	private final int gameH = 800;
	public final int framesPerSecond = 120;
	Random r = new Random();
	private int Puntos = 0;
	private int Nivel = 1;
	private int Vidas = 3;
	private int markerX, markerY;
	private static int BossHitPoints = 5;
	private static int FinalBossHitPoints = 10;
	public Nave MillenniumFalcon;
	public Enemigo EmpireHunter;
	public Enemigo StarDestroyer;
	public Enemigo DeathStar;
	public Misil Laser;
	private boolean BulletFire = true;
	private boolean BeamFire = true;
	private boolean Randomize = true;
	private boolean HitMarker = false;
	private boolean Alive = true;
	LinkedList EnemyList = new LinkedList ();
	private ImageIcon Background = new ImageIcon ("Background.jpg");
	private File BlasterFiring = new File ("blaster-firing.wav");
	private File BossFight = new File ("imperial_march.wav");
	private File Death = new File ("jabba-the-hut-laughing.wav");
	private File HitMarkers = new File ("R2D2-do.wav");
	private File LevelUp = new File ("R2D2-yeah.wav");
	private File GameMusic1 = new File ("star-wars-theme-song.wav");
	private File GameMusic2 = new File ("rebel-theme.wav");
	private AudioInputStream audioIn;
	private Clip clip;
	
	public static int getBossHealth()
	{
		return BossHitPoints;
	}
	public static int getFinalBossHealth ()
	{
		return FinalBossHitPoints;
	}
	public final void GameSetup ()
	{
		if (Nivel == 1) 
			{
			JOptionPane.showMessageDialog(null, "En una galaxia muy, muy lejana");
			try 
			{
				audioIn = AudioSystem.getAudioInputStream(GameMusic1);
				clip = AudioSystem.getClip();
				clip.open(audioIn);
				clip.start();
				} catch (UnsupportedAudioFileException e) {
		         e.printStackTrace();
				} catch (IOException e) {
		         e.printStackTrace();
				} catch (LineUnavailableException e) {
		         e.printStackTrace();
			}
			for (int fila = 0; fila < 5; fila ++)
			{
				for (int columna = 0; columna < 6; columna ++)
				{
					EmpireHunter = new Enemigo (20 + (fila * 100), 20 + (columna * 60), Nivel, 0, 40, 40, 0, null);
					EnemyList.insertFirst(EmpireHunter);
				}
			}
		}
		teclado.resetControls();
		MillenniumFalcon = new Nave (375, 730, null, teclado);
		if (Nivel == 2)
		{
			for (int fila = 0; fila < 5; fila ++)
			{
				for (int columna = 0; columna < 6; columna ++)
				{
					EmpireHunter = new Enemigo (20 + (fila * 100), 20 + (columna * 60), Nivel, 0, 40, 40, 0, null);
					EnemyList.insertFirst(EmpireHunter);
					StarDestroyer = new Enemigo (20 + (fila * 100), 20 + (columna * 60), Nivel, 0, 40, 40, 50, null);
				}
			}
			int rand = r.nextInt(EnemyList.size());
			EnemyList.insertAnyPosition(StarDestroyer, rand);
			if (Alive = false)
			{
				EnemyList.isEmpty();
			}
		}
		if (Nivel == 3)
		{
			for (int fila = 0; fila < 5; fila ++)
			{
				for (int columna = 0; columna < 6; columna ++)
				{
					EmpireHunter = new Enemigo (20 + (fila * 100), 20 + (columna * 60), Nivel, 0, 40, 40, 0, null);
					EnemyList.insertFirst(EmpireHunter);
					StarDestroyer = new Enemigo (20 + (fila * 100), 20 + (columna * 60), Nivel, 0, 40, 40, 50, null);
				}
			}
			int rand = r.nextInt(EnemyList.size());
			EnemyList.insertAnyPosition(StarDestroyer, rand);
			while (Randomize = true)
			{
				EnemyList.sortData();
			}
		}
		if (Nivel == 4)
		{
			for (int fila = 0; fila < 5; fila ++)
			{
				for (int columna = 0; columna < 6; columna ++)
				{
					EmpireHunter = new Enemigo (20 + (fila * 100), 20 + (columna * 60), Nivel, 0, 40, 40, 0, null);
					EnemyList.insertFirst(EmpireHunter);
					StarDestroyer = new Enemigo (20 + (fila * 100), 20 + (columna * 60), Nivel, 0, 40, 40, 50, null);
				}
			}
			int rand = r.nextInt(EnemyList.size());
			EnemyList.insertAnyPosition(StarDestroyer, rand);
			if (Alive = false)
			{
				EnemyList.insertAnyPosition(StarDestroyer, rand);
			}
		}
		if (Nivel == 5)
		{
			try 
			{
				audioIn = AudioSystem.getAudioInputStream(BossFight);
				clip = AudioSystem.getClip();
				clip.open(audioIn);
				clip.start();
				} catch (UnsupportedAudioFileException e) {
		         e.printStackTrace();
				} catch (IOException e) {
		         e.printStackTrace();
				} catch (LineUnavailableException e) {
		         e.printStackTrace();
			}
			DeathStar = new Enemigo (20, 20, Nivel, 0, 40, 40, 100, null);
			EnemyList.insertFirst(DeathStar);
		}
	}
	@Override
	public void paint (Graphics g)
	{
		Background.paintIcon(null, g, 0, -150);
		if (Laser != null)
		{
			if (HitMarker)
			{
				g.setColor(Color.WHITE);
				if (Nivel == 5)
				{
					g.drawString("+100", markerX + 20, markerY -= 1);
				} else {
					g.drawString("-1", markerX + 75, markerY -= 1);
				}
			}
		}
		MillenniumFalcon.draw(g);
		try 
		{
			for (int indice = 0; indice < EnemyList.size(); indice++)
			{
				EnemyList.get(indice).draw(g);
			}	
		} catch (IndexOutOfBoundsException e) {
		}
		if (teclado.getKeyStatus(32))
		{
			if (BulletFire)
			{
				Laser = new Misil (MillenniumFalcon.getX() + 22, MillenniumFalcon.getY() - 20, 0, Color.RED);
				try
				{
					audioIn = AudioSystem.getAudioInputStream(BlasterFiring);
					clip = AudioSystem.getClip();
					clip.open(audioIn);
					clip.start();
					} catch (UnsupportedAudioFileException e) {
			         e.printStackTrace();
					} catch (IOException e) {
			         e.printStackTrace();
					} catch (LineUnavailableException e) {
			         e.printStackTrace();
				}
				BulletFire = false;
			}
		}
		if (Laser != null)
		{
			Laser.draw(g);
		}
		//Muestra la puntuaci�n
		g.setColor(Color.WHITE);
		g.drawString("Puntuaci�n:" + Puntos, 260, 20);
		//Muestra el nivel actual
		g.setColor(Color.WHITE);
		g.drawString("Nivel:" + Nivel, 750, 20);
		//Muestra la lista actual
		if (Nivel == 5)
		{
			g.setColor(Color.WHITE);
			g.drawString("Salud:" + FinalBossHitPoints, 352, 600);
		}
	}
	public void UpdateGame (int frameNumber)
	{
		MillenniumFalcon.move();
		if ((EnemyList.get(EnemyList.size() - 1).getX()) + (EnemyList.get(EnemyList.size() - 1).getxVel()) > 760)
		{
			for (int indice = 0; indice < EnemyList.size(); indice++)
			{
				EnemyList.get(indice).setxVel(EnemyList.get(indice).getX() * -1);
                EnemyList.get(indice).setyVel(EnemyList.get(indice).getY() + 10);
			}
		}
		else if (EnemyList.get(0).getX() + EnemyList.get(0).getxVel() < 0)
		{
			for (int indice = 0; indice < EnemyList.size(); indice++)
			{
				EnemyList.get(indice).setxVel(EnemyList.get(indice).getX() * -1);
                EnemyList.get(indice).setyVel(EnemyList.get(indice).getY() + 10);
			}
		} else {
			for (int indice = 0; indice < EnemyList.size(); indice++) {
                EnemyList.get(indice).move();
            }
		}
		if (Laser != null)
		{
			Laser.setY(Laser.getY() - 15);
			if (Laser.getY() < 0)
			{
				BulletFire = true;
			}
		}
		 for (int indice = 0; indice < EnemyList.size(); indice++) {
             if (Laser.colision(EnemyList.get(indice))) {
            	 try
 				{
 					audioIn = AudioSystem.getAudioInputStream(HitMarkers);
 					clip = AudioSystem.getClip();
 					clip.open(audioIn);
 					clip.start();
 					} catch (UnsupportedAudioFileException e) {
 			         e.printStackTrace();
 					} catch (IOException e) {
 			         e.printStackTrace();
 					} catch (LineUnavailableException e) {
 			         e.printStackTrace();
 				}
                 Laser = new Misil(0, 0, 0, null);
                 BulletFire = true;
                 // Cambia el puntaje
                 if (Nivel != 5) {
                     Puntos += 100;
                     HitMarker = true;
                     markerX = EnemyList.get(indice).getX(); // Gets positions that the "+ 100" spawns off of
                     markerY = EnemyList.get(indice).getY();
                     EnemyList.delete(indice);
                     Alive = false;
                 }
             }
    		 if (Nivel == 5) {
                 HitMarker = true;
                 markerX = EnemyList.get(indice).getX();
                 markerY = EnemyList.get(indice).getY() + 165;
                 FinalBossHitPoints -= 1;
                 if (FinalBossHitPoints == 0) {
                     EnemyList.delete(indice);
                     Puntos += 10000;
                     Alive = false;
                 }
    		 }
    		  if ((EnemyList.get(indice).getY() + 50 >= 750) && (MillenniumFalcon.colision)) {
                  try
                  {
                	audioIn = AudioSystem.getAudioInputStream(Death);
  					clip = AudioSystem.getClip();
  					clip.open(audioIn);
  					clip.start();
  					} catch (UnsupportedAudioFileException e) {
  			         e.printStackTrace();
  					} catch (IOException e) {
  			         e.printStackTrace();
  					} catch (LineUnavailableException e) {
  			         e.printStackTrace();
                  }
                  int respuesta = JOptionPane.showConfirmDialog(null, "�Quiere jugar de nuevo?", "Su m�xima puntuaci�n fue:" + Puntos + " puntos", 0);
                  if (respuesta == 0)
                  {
                      EnemyList.isEmpty();
                      BossHitPoints = 5;
                      FinalBossHitPoints = 10;
                      Puntos = 0;
                      Nivel = 1;
                      BulletFire = true;
                      Alive = true;
                      HitMarker = true;
                      Randomize = true;
                      GameSetup();
                  } 
                  else if (respuesta == 1)
                  {
                	  System.exit(1);
                  }
                  if (EnemyList.isEmpty());
                  Nivel += 1;
                  BossHitPoints = 5;
                  FinalBossHitPoints = 10;
                  GameSetup();
                  try
                  {
                      audioIn = AudioSystem.getAudioInputStream(LevelUp);
        				clip = AudioSystem.getClip();
        				clip.open(audioIn);
        				clip.start();
        				} catch (UnsupportedAudioFileException e) {
        			        e.printStackTrace();
        				} catch (IOException e) {
        			         e.printStackTrace();
        				} catch (LineUnavailableException e) {
        			        e.printStackTrace();
                  }
              }
		 }
	}
	public void Game ()
	{
        this.setSize(gameW, gameH);
        this.setPreferredSize(new Dimension(gameW, gameH));
        this.setBackground(Color.BLACK);
        teclado = new Teclado ();
        this.addKeyListener(teclado);
        this.GameSetup();
        this.setFocusable(true);
        this.requestFocusInWindow();
	}
	public void Start ()
	{
		GameTimer = new Timer(1000 / framesPerSecond, new ActionListener() 
				{
			private int frameNumber = 0;
			@Override
			public void actionPerformed (ActionEvent e)
			{
				UpdateGame(frameNumber++);
				repaint();
			}
		});
		Timer GameTimerHitMarker = new Timer (1000, new ActionListener() 
				{
			public void actionPerformed (ActionEvent e)
			{
				HitMarker = false;
			}
		});
		GameTimer.setRepeats(true);
		GameTimer.start();
		GameTimerHitMarker.setRepeats(true);
		GameTimerHitMarker.start();
	}
}
