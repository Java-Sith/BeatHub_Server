package Invasion;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Graphics;
import Invasion.LinkedList;
import javax.swing.ImageIcon;

public class Enemigo extends ObjetoMovible {
	ImageIcon Imperial1 = new ImageIcon ("Images/EmpireHunter.png");
	ImageIcon Imperial2 = new ImageIcon ("Images/StarDestroyer.jpg");
	ImageIcon Imperial3 = new ImageIcon ("Images/DeathStar.jpg");
	public int w, h, type;
	
	//Constructor de la clase
	public Enemigo (int x, int y, int xVel, int yVel, int w, int h, int type, Color color) 
	{
		super (x, y, xVel, yVel, color);
		this.w = w;
		this.type = type;
		this.h = h;
	}
	public int getW() 
	{
		return w;
	}
	public void setW(int w) 
	{
		this.w = w;
	}
	public int getH() 
	{
		return h;
	}
	public void setH(int h) 
	{
		this.h = h;
	}
	public int getType() 
	{
		return type;
	}
	public void setType(int type) 
	{
		this.type = type;
	}
	@Override
	public void draw (Graphics g)
	{
		if (this.type == 100) 
		{
			Imperial3.paintIcon(null, g, this.getX(), this.getY());
		}
		else if (this.type == 50)
		{
			Imperial2.paintIcon(null, g, this.getX(), this.getY());
		} else {
			Imperial1.paintIcon(null, g, this.getX(), this.getY());
		}
	}
	public Rectangle getBounds()
	{
		Rectangle enemyhitBox = new Rectangle (this.getX(), this.getY(), w, h);
		return enemyhitBox;
	}
}
