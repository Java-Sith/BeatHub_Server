package Invasion;

public interface Movimiento {
	public void move ();
}
