package Invasion;
import Controls.Teclado;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public abstract class ObjetoControlable extends ObjetoJuego implements Movimiento {
	Teclado teclado;
	public ObjetoControlable (int x, int y, Color color, Teclado teclado)
	{
		super (x, y, color);
		this.teclado = teclado;
	}
}
