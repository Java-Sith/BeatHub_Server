package Invasion;
import java.awt.Graphics;

public interface Dibujo {
	public void draw (Graphics g);
}
