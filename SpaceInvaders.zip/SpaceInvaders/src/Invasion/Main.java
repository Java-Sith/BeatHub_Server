package Invasion;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.awt.EventQueue.invokeLater(new Runnable () {
				@Override
				public void run() {
					new Frame().setVisible (true);
				}
			});
	}

}
