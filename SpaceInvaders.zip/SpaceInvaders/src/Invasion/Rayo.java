package Invasion;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Rayo extends ObjetoMovible{
	public Rayo (int x, int y, int diameter, Color color)
	{
		super (x, y, 0, 0, color);
	}
	@Override
	public void draw (Graphics g)
	{
		g.setColor(color);
		g.fillRect(this.getX(), this.getY(), 5, 20);
	}
	@Override
	public Rectangle getBounds ()
	{
		Rectangle RayoHitBox = new Rectangle (x, y, 5, 20);
		return RayoHitBox;
	}
}
