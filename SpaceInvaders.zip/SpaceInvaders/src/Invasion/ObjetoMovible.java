package Invasion;
import java.awt.Color;

public abstract class ObjetoMovible extends ObjetoJuego implements Movimiento{
	int xVel;
	int yVel;
	
	public ObjetoMovible (int x, int y, int xVel, int yVel, Color color)
	{
		super (x, y, color);
		this.xVel = xVel;
		this.yVel = yVel;
	}
	public int getxVel() {
		return xVel;
	}

	public void setxVel(int xVel) {
		this.xVel = xVel;
	}

	public int getyVel() {
		return yVel;
	}

	public void setyVel(int yVel) {
		this.yVel = yVel;
	}
	@Override
	public void move ()
	{
		this.x += xVel;
		this.y += yVel;
	}
}
