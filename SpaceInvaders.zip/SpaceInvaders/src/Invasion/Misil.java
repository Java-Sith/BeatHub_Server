package Invasion;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Misil extends ObjetoMovible {
	int diametro;
	int yVel;
	
	public Misil (int x, int y, int diametro, Color color)
	{
		super (x, y, 0, 0, color);
		this.diametro = diametro;
	}
	public int getDiametro ()
	{
		return diametro;
	}
	@Override
	public void draw (Graphics g)
	{
		g.setColor(color);
		g.fillRect(this.getX(), this.getY(), 5, 20);
	}
	@Override
	public Rectangle getBounds ()
	{
		Rectangle MisilHitBox = new Rectangle (x, y, 5, 20);
		return MisilHitBox;
	}
}
