package Invasion;
import Controls.Teclado;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.ImageIcon;

public class Nave extends ObjetoControlable {
	ImageIcon Nave = new ImageIcon ("Images/MillenniumFalcon.png");
	public Nave (int x, int y, Color color, Teclado teclado) 
	{
		super (x, y, color, teclado);
	}
	@Override
	public void draw (Graphics g)
	{
		Nave.paintIcon(null, g, this.getX(), this.getY());
	}
	@Override
	public Rectangle getBounds ()
	{
		Rectangle naveHitBox = new Rectangle (this.getX(), this.getY(), 50, 50);
		return naveHitBox;
	}
	@Override
	public void move ()
	{
		if (teclado.getKeyStatus(37))
		{
			x -= 10;
		}
		if (teclado.getKeyStatus(39))
		{
			x += 10;
		}
		if (x > 800)
		{
			x -= 50;
		}
		if (x < -50)
		{
			x = 800;
		}
	}
}
