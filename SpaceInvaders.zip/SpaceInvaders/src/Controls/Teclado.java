package Controls;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

//Define la clase Teclado que ser� implementada
public class Teclado implements KeyListener {
	//Booleano que regresa un estado
	private boolean [] keyStatus;
	//Constructor de la clase
	public Teclado () 
	{
		keyStatus = new boolean [256];
	}
	public boolean getKeyStatus (int keyCode)
	{
		if (keyCode < 0 || keyCode > 255)
		{
			return false;
		}
		else
		{
			return keyStatus [keyCode];
		}
	}
	public void resetControls ()
	{
		keyStatus = new boolean [256];
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		keyStatus[e.getKeyCode()] = true;
		
	}
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		keyStatus[e.getKeyCode()] = false;
	}
}
